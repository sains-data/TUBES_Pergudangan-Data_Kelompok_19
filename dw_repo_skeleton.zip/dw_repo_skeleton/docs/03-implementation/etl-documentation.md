# ETL Documentation
## Orkestrasi
- Urutan: Staging → Dimensi → Fakta → Indeks/Partisi
## Staging
- Extract dari ERP/CRM menyimpan *raw snapshot* harian.
## Dimensi
- SCD Type 2 untuk Product & Customer.
## Fakta
- Grain: order line; foreign key surrogates; measures: Quantity, UnitPrice, ExtendedAmount.
