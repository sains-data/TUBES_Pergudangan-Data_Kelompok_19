# Data Sources
| System | Table / Endpoint | Frequency | Owner | Notes |
|---|---|---|---|---|
| ERP | SalesOrderHeader / SalesOrderDetail | Daily | Ops ERP | Primary sales facts |
| CRM | Customers | Daily | CRM Team | Surrogate key by CustomerAlternateKey |
| CSV | Promotions.csv | On demand | Marketing | Mapping campaign to dimension |
