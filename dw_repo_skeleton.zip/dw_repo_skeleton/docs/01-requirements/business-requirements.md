# Business Requirements
- **Objectives**: (contoh) Metrik penjualan harian, top-N produk, dan churn pelanggan.
- **KPIs**: Revenue, Margin, Conversion Rate, AOV.
- **Grain**: FactInternetSales berbutir *order line*.
- **Dimensions**: Date, Customer, Product, Geography, Promotion, Sales Territory.
- **Assumptions/Constraints**: SLA refresh D+1, data sumber dari ERP & CRM.
