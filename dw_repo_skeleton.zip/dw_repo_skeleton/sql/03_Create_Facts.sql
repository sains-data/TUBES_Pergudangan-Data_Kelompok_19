-- 03_Create_Facts.sql
USE DW;
GO
CREATE TABLE fact.InternetSales (
  SalesKey          BIGINT IDENTITY(1,1) PRIMARY KEY,
  DateKey           INT NOT NULL FOREIGN KEY REFERENCES dim.Date(DateKey),
  CustomerKey       INT NOT NULL FOREIGN KEY REFERENCES dim.Customer(CustomerKey),
  ProductKey        INT NOT NULL FOREIGN KEY REFERENCES dim.Product(ProductKey),
  OrderNumber       NVARCHAR(25),
  OrderLine         SMALLINT,
  Quantity          INT,
  UnitPrice         DECIMAL(19,4),
  ExtendedAmount    AS (Quantity * UnitPrice) PERSISTED
);
