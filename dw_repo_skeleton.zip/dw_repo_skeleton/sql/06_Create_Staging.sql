-- 06_Create_Staging.sql
USE DW;
GO
CREATE TABLE stage.SalesOrderHeader_Raw (...);
CREATE TABLE stage.SalesOrderDetail_Raw (...);
-- Add other raw staging tables as needed.
