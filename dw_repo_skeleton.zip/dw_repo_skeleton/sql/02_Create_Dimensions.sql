-- 02_Create_Dimensions.sql
USE DW;
GO
CREATE TABLE dim.Date (
  DateKey        INT PRIMARY KEY,      -- yyyymmdd
  [Date]         DATE NOT NULL,
  DayName        NVARCHAR(20),
  MonthName      NVARCHAR(20),
  MonthNumber    TINYINT,
  Quarter        TINYINT,
  Year           SMALLINT
);

CREATE TABLE dim.Customer (
  CustomerKey    INT IDENTITY(1,1) PRIMARY KEY,
  CustomerAltKey INT,
  Name           NVARCHAR(200),
  City           NVARCHAR(100),
  StateProvince  NVARCHAR(100),
  Country        NVARCHAR(100),
  StartDate      DATE,
  EndDate        DATE,
  IsCurrent      BIT
);

CREATE TABLE dim.Product (
  ProductKey     INT IDENTITY(1,1) PRIMARY KEY,
  ProductAltKey  INT,
  ProductName    NVARCHAR(200),
  Subcategory    NVARCHAR(100),
  Category       NVARCHAR(100),
  StartDate      DATE,
  EndDate        DATE,
  IsCurrent      BIT
);
