-- 04_Create_Indexes.sql
USE DW;
GO
CREATE INDEX IX_fact_InternetSales_Date ON fact.InternetSales(DateKey);
CREATE INDEX IX_fact_InternetSales_Customer ON fact.InternetSales(CustomerKey);
CREATE INDEX IX_fact_InternetSales_Product ON fact.InternetSales(ProductKey);
