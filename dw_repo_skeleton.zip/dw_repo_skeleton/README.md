# Data Warehouse Project

Struktur repo ini mengikuti praktik umum untuk proyek DW/BI:
- `docs/` → kebutuhan, desain, dan dokumentasi implementasi
- `sql/` → skrip pembuatan database/dimensi/fakta/indeks/partisi/staging
- `etl/` → paket & skrip ETL/ELT
- `dashboards/` → artefak BI (mis. Power BI)
- `tests/` → skrip pengujian

## Cara pakai cepat
1. Tulis kebutuhan di `docs/01-requirements/`.
2. Simpan ERD dan model dimensional di `docs/02-design/` dan isi `data-dictionary.xlsx`.
3. Implementasi skema dengan skrip di `sql/` (urut 01 → 06).
4. Simpan paket/shell/py ETL di `etl/`.
5. Simpan file dashboard di `dashboards/`.
6. Tambahkan uji validasi di `tests/`.
